function y = g(x)
    % SOAL 1: f(x) = x^3 - 6x
    % y = (6*x)^(1/3);
    % y = (x^3)/6;
    % y = 6 / x;

    % SOAL 2: f(x) = x^2 + x + 2
    % y = -x^2 - 2;
    % y = sqrt(-x-2);
    % y = -2 / (x + 1);

    % SOAL 3: f(x) = sin(x) - 0.5
    % y = x + sin(x) - 0.5;
    y = asin(0.5);
end


